========
mesh_sql
========


.. image:: https://img.shields.io/pypi/v/template.svg
        :target: https://pypi.python.org/pypi/template

.. image:: https://img.shields.io/travis/petermeshack/template.svg
        :target: https://travis-ci.com/petermeshack/template

.. image:: https://readthedocs.org/projects/template/badge/?version=latest
        :target: https://template.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status




easy creation of database plus manipulation


* Free software: MIT license
* Documentation: https://template.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
