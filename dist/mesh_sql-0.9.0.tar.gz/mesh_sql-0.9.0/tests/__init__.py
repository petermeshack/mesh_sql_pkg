#!/usr/bin/env python
"""Unit test package for _template."""