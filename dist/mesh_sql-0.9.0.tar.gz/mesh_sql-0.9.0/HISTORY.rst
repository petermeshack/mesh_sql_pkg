=======
History
=======

0.9.0 (2022-07-27)
------------------

* First release as library.
